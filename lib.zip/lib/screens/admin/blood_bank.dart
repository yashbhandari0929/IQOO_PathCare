// lib/screens/patient/blood_bank_screen.dart
//
// REQUIRED pubspec.yaml packages:
//   flutter_map: ^6.1.0
//   latlong2: ^0.9.0
//   url_launcher: ^6.2.0
//   http: ^1.2.0
//   flutter_map_cancellable_tile_provider: ^3.0.0
//
// DATA SOURCES:
//   1. eRaktKosh (mohfw.gov.in) — official govt-registered blood banks
//      Maharashtra stateCode = 27
//      Mumbai district codes: 524 (Mumbai City), 525 (Mumbai Suburban)
//      Endpoint: POST https://eraktkosh.mohfw.gov.in/BLDAHIMS/bloodbank/transactions/hsbcstockavailability.cnt
//      Parameters: stateCode, districtCode, bloodGroup (empty = all), compType=1, Etype=changehsbc
//
//   2. OpenStreetMap Overpass API — crowd-sourced blood banks
//      Bounding box covers Greater Mumbai: (18.8,72.7,19.4,73.1)
//
//   Both lists are merged and deduplicated by proximity (< 150m = same bank).
//   eRaktKosh entries always win on merge (they have live blood stock data).

import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_map_cancellable_tile_provider/flutter_map_cancellable_tile_provider.dart';

// ── Constants ─────────────────────────────────────────────────
const String _demoPhone      = '+919876543210';
const String _predefinedMsg  =
    '🚨 URGENT BLOOD REQUEST 🚨\n\n'
    'Hello, I urgently need blood. This is a medical emergency.\n'
    'Please assist or guide me to the nearest available blood unit.\n\n'
    'Thank you 🙏';

// Blood group display order
const List<String> _bloodGroups = [
  'A+', 'A−', 'B+', 'B−', 'AB+', 'AB−', 'O+', 'O−',
];

// ── Source tag ────────────────────────────────────────────────
enum BankSource { eRaktKosh, osm, both }

// ── Model ─────────────────────────────────────────────────────
class BloodBank {
  final String     id;
  final String     name;
  final String     address;
  final String     phone;
  final double     latitude;
  final double     longitude;
  final String     timing;
  final String     type;
  final String     area;
  final BankSource source;

  // Blood stock from eRaktKosh — null means not available from this source
  // Map<bloodGroup, unitsAvailable>  e.g. {'A+': 3, 'O−': 0}
  final Map<String, int>? bloodStock;

  BloodBank({
    required this.id,
    required this.name,
    required this.address,
    required this.phone,
    required this.latitude,
    required this.longitude,
    required this.timing,
    required this.type,
    required this.area,
    required this.source,
    this.bloodStock,
  });

  String get effectivePhone =>
      (phone == 'N/A' || phone.isEmpty) ? _demoPhone : phone;

  bool get hasRealPhone => phone != 'N/A' && phone.isNotEmpty;

  bool get hasStockData => bloodStock != null && bloodStock!.isNotEmpty;

  // Any blood group with > 0 units
  bool get hasAvailableBlood =>
      bloodStock?.values.any((v) => v > 0) ?? false;

  // ── Build from eRaktKosh JSON ─────────────────────────────
  factory BloodBank.fromERaktKosh(Map<String, dynamic> e) {
    // eRaktKosh response fields (as observed from network inspection):
    // bbName, address, pinCode, state, district, contactNo, latitude,
    // longitude, timing, category (Govt/Private/Trust),
    // bloodGroupDetails: [{bloodGroup, totalUnit}]

    final name    = e['bbName']    as String? ?? e['name']    as String? ?? 'Blood Bank';
    final address = e['address']   as String? ?? '';
    final phone   = e['contactNo'] as String? ?? e['phone']   as String? ?? 'N/A';
    final lat     = _parseDouble(e['latitude']  ?? e['lat']);
    final lon     = _parseDouble(e['longitude'] ?? e['lon']);
    final timing  = e['timing']    as String? ?? '24/7';
    final area    = e['district']  as String? ?? 'Mumbai';

    // Category → type
    final cat  = (e['category'] as String? ?? '').toLowerCase();
    String type = 'Private';
    if (cat.contains('govt') || cat.contains('government')) {
      type = 'Government';
    } else if (cat.contains('trust') || cat.contains('ngo')) {
      type = 'Trust';
    }

    // Parse blood stock
    final Map<String, int> stock = {};
    final details = e['bloodGroupDetails'] as List<dynamic>?;
    if (details != null) {
      for (final d in details) {
        final bg    = d['bloodGroup'] as String? ?? '';
        final units = _parseInt(d['totalUnit'] ?? d['units'] ?? 0);
        if (bg.isNotEmpty) stock[bg] = units;
      }
    }

    return BloodBank(
      id:         'erk_${e['bbId'] ?? name.hashCode}',
      name:       name,
      address:    address,
      phone:      phone.isEmpty ? 'N/A' : phone,
      latitude:   lat,
      longitude:  lon,
      timing:     timing,
      type:       type,
      area:       area,
      source:     BankSource.eRaktKosh,
      bloodStock: stock.isEmpty ? null : stock,
    );
  }

  // ── Build from OSM element ────────────────────────────────
  factory BloodBank.fromOSM(Map<String, dynamic> element) {
    final tags = element['tags'] as Map<String, dynamic>? ?? {};
    final lat  = (element['lat'] as num?)?.toDouble() ??
        ((element['center']?['lat'] as num?)?.toDouble() ?? 0.0);
    final lon  = (element['lon'] as num?)?.toDouble() ??
        ((element['center']?['lon'] as num?)?.toDouble() ?? 0.0);

    final parts = <String>[];
    if (tags['addr:housenumber'] != null) parts.add(tags['addr:housenumber']);
    if (tags['addr:street']      != null) parts.add(tags['addr:street']);
    if (tags['addr:suburb']      != null) parts.add(tags['addr:suburb']);
    if (tags['addr:city']        != null) parts.add(tags['addr:city']);
    final address = parts.isNotEmpty ? parts.join(', ') : 'Mumbai';

    final area     = tags['addr:suburb']       ??
        tags['addr:neighbourhood'] ??
        tags['addr:district']      ??
        'Mumbai';
    final operator = (tags['operator'] ?? '').toLowerCase();
    String type    = 'Private';
    if (operator.contains('government') || operator.contains('govt') ||
        operator.contains('municipal')  || operator.contains('bmc') ||
        operator.contains('state')      ||
        tags['operator:type']        == 'government' ||
        tags['healthcare:speciality'] == 'government') {
      type = 'Government';
    } else if (operator.contains('trust') || operator.contains('ngo') ||
        operator.contains('charity') || operator.contains('red cross')) {
      type = 'Trust';
    }

    return BloodBank(
      id:        'osm_${element['id']}',
      name:      tags['name'] ?? tags['operator'] ?? 'Blood Bank',
      address:   address,
      phone:     tags['phone'] ?? tags['contact:phone'] ??
          tags['contact:mobile'] ?? 'N/A',
      latitude:  lat,
      longitude: lon,
      timing:    tags['opening_hours'] ?? '24/7',
      type:      type,
      area:      area,
      source:    BankSource.osm,
    );
  }

  static double _parseDouble(dynamic v) {
    if (v == null) return 0.0;
    if (v is double) return v;
    if (v is int)    return v.toDouble();
    return double.tryParse(v.toString()) ?? 0.0;
  }

  static int _parseInt(dynamic v) {
    if (v == null) return 0;
    if (v is int)    return v;
    if (v is double) return v.toInt();
    return int.tryParse(v.toString()) ?? 0;
  }
}

// ── Screen ────────────────────────────────────────────────────
class BloodBankScreen extends StatefulWidget {
  const BloodBankScreen({Key? key}) : super(key: key);

  @override
  State<BloodBankScreen> createState() => _BloodBankScreenState();
}

class _BloodBankScreenState extends State<BloodBankScreen>
    with SingleTickerProviderStateMixin {
  static const LatLng _mumbaiCenter = LatLng(19.0760, 72.8777);

  final TextEditingController _searchController = TextEditingController();
  final MapController         _mapController    = MapController();
  late  TabController         _tabController;

  List<BloodBank> _bloodBanks    = [];
  bool            _isLoading     = true;
  String?         _errorMessage;
  String          _searchQuery   = '';
  BloodBank?      _selectedBank;
  String          _selectedType  = 'All';
  DateTime?       _lastFetched;

  // Source filter
  String _sourceFilter = 'All'; // All / eRaktKosh / OSM

  // Blood group filter (for eRaktKosh stock)
  String? _bloodGroupFilter; // null = no filter

  // Stats
  int _erkCount = 0;
  int _osmCount = 0;

  final List<String> _typeFilters   = ['All', 'Government', 'Private', 'Trust'];
  final List<String> _sourceFilters = ['All', 'eRaktKosh', 'OSM Only'];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _fetchAll();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _tabController.dispose();
    _mapController.dispose();
    super.dispose();
  }

  // ── FETCH BOTH SOURCES IN PARALLEL ───────────────────────
  Future<void> _fetchAll() async {
    if (mounted) setState(() { _isLoading = true; _errorMessage = null; });

    try {
      // Run both fetches simultaneously
      final results = await Future.wait([
        _fetchERaktKosh(),
        _fetchOSM(),
      ]);

      final erkBanks = results[0];
      final osmBanks = results[1];

      // Merge: deduplicate entries within 150m of each other
      // eRaktKosh entries take priority (they have blood stock data)
      final merged = _mergeBanks(erkBanks, osmBanks);
      merged.sort((a, b) => a.name.compareTo(b.name));

      if (mounted) {
        setState(() {
          _bloodBanks  = merged;
          _erkCount    = erkBanks.length;
          _osmCount    = osmBanks.length;
          _isLoading   = false;
          _lastFetched = DateTime.now();
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading    = false;
          _errorMessage = 'Could not load data.\n${e.toString()}';
        });
      }
    }
  }

  // ── eRaktKosh fetch ───────────────────────────────────────
  // Maharashtra = stateCode 27
  // Mumbai City = districtCode 524
  // Mumbai Suburban = districtCode 525
  // We fetch both districts and combine.
  Future<List<BloodBank>> _fetchERaktKosh() async {
    const base = 'https://eraktkosh.mohfw.gov.in/BLDAHIMS/bloodbank/transactions/hsbcstockavailability.cnt';

    final List<BloodBank> banks = [];

    // Fetch for both Mumbai districts
    for (final distCode in ['524', '525']) {
      try {
        final body =
            'stateCode=27'
            '&districtCode=$distCode'
            '&bloodGroup='
            '&compType=1'
            '&Etype=changehsbc';

        final resp = await http.post(
          Uri.parse(base),
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept':       'application/json, text/plain, */*',
            'Origin':       'https://eraktkosh.mohfw.gov.in',
            'Referer':      'https://eraktkosh.mohfw.gov.in/',
          },
          body: body,
        ).timeout(const Duration(seconds: 20));

        if (resp.statusCode == 200 && resp.body.trim().isNotEmpty) {
          final decoded = _safeJsonDecode(resp.body);
          if (decoded is List) {
            for (final e in decoded) {
              try {
                final bank = BloodBank.fromERaktKosh(e as Map<String, dynamic>);
                if (bank.latitude != 0.0 && bank.longitude != 0.0) {
                  banks.add(bank);
                }
              } catch (_) {}
            }
          } else if (decoded is Map && decoded['data'] is List) {
            for (final e in decoded['data']) {
              try {
                final bank = BloodBank.fromERaktKosh(e as Map<String, dynamic>);
                if (bank.latitude != 0.0 && bank.longitude != 0.0) {
                  banks.add(bank);
                }
              } catch (_) {}
            }
          }
        }
      } catch (e) {
        print('eRaktKosh dist $distCode error: $e');
        // Don't fail entire fetch if one district fails
      }
    }

    print('✅ eRaktKosh returned ${banks.length} banks');
    return banks;
  }

  // ── OSM fetch ─────────────────────────────────────────────
  Future<List<BloodBank>> _fetchOSM() async {
    const query = '''
[out:json][timeout:30];
(
  node["amenity"="blood_bank"](18.8,72.7,19.4,73.1);
  way["amenity"="blood_bank"](18.8,72.7,19.4,73.1);
  relation["amenity"="blood_bank"](18.8,72.7,19.4,73.1);
  node["healthcare"="blood_bank"](18.8,72.7,19.4,73.1);
  way["healthcare"="blood_bank"](18.8,72.7,19.4,73.1);
  node["healthcare"="blood_donation"](18.8,72.7,19.4,73.1);
  way["healthcare"="blood_donation"](18.8,72.7,19.4,73.1);
  node["name"~"[Bb]lood [Bb]ank"](18.8,72.7,19.4,73.1);
  way["name"~"[Bb]lood [Bb]ank"](18.8,72.7,19.4,73.1);
);
out center;
''';

    final resp = await http.post(
      Uri.parse('https://overpass-api.de/api/interpreter'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'data=${Uri.encodeComponent(query)}',
    ).timeout(const Duration(seconds: 30));

    if (resp.statusCode != 200) return [];

    final data     = jsonDecode(resp.body);
    final elements = data['elements'] as List<dynamic>;
    final banks    = elements
        .map((e) => BloodBank.fromOSM(e as Map<String, dynamic>))
        .where((b) => b.latitude != 0.0 && b.longitude != 0.0)
        .toList();

    print('✅ OSM returned ${banks.length} banks');
    return banks;
  }

  // ── Merge & deduplicate ────────────────────────────────────
  // If an eRaktKosh bank and an OSM bank are within 150m of each other,
  // they refer to the same physical location.
  // Keep the eRaktKosh one (has blood stock) but mark source = both.
  List<BloodBank> _mergeBanks(
      List<BloodBank> erk, List<BloodBank> osm) {
    final merged = <BloodBank>[...erk];
    final used   = <int>{};

    for (int o = 0; o < osm.length; o++) {
      bool isDuplicate = false;
      for (final e in erk) {
        final dist = _haversineMeters(
          osm[o].latitude,  osm[o].longitude,
          e.latitude,       e.longitude,
        );
        if (dist < 150) {
          isDuplicate = true;
          // Mark eRaktKosh entry as confirmed by OSM too
          final idx = merged.indexOf(e);
          if (idx >= 0) {
            merged[idx] = BloodBank(
              id:         e.id,
              name:       e.name,
              address:    e.address.isNotEmpty ? e.address : osm[o].address,
              phone:      e.hasRealPhone ? e.phone : osm[o].phone,
              latitude:   e.latitude,
              longitude:  e.longitude,
              timing:     e.timing,
              type:       e.type,
              area:       e.area,
              source:     BankSource.both,
              bloodStock: e.bloodStock,
            );
          }
          used.add(o);
          break;
        }
      }
      if (!isDuplicate) {
        merged.add(osm[o]);
      }
    }
    return merged;
  }

  // Haversine formula — distance in metres between two lat/lon points
  double _haversineMeters(
      double lat1, double lon1, double lat2, double lon2) {
    const r    = 6371000.0;
    final dLat = _toRad(lat2 - lat1);
    final dLon = _toRad(lon2 - lon1);
    final a    = sin(dLat / 2) * sin(dLat / 2) +
        cos(_toRad(lat1)) * cos(_toRad(lat2)) *
            sin(dLon / 2) * sin(dLon / 2);
    return r * 2 * atan2(sqrt(a), sqrt(1 - a));
  }

  double _toRad(double deg) => deg * pi / 180;

  // ── Safe JSON decode (eRaktKosh sometimes returns HTML on error) ──
  dynamic _safeJsonDecode(String body) {
    try {
      return jsonDecode(body);
    } catch (_) {
      return null;
    }
  }

  // ── Communication ─────────────────────────────────────────
  Future<void> _launchCall(String phone) async {
    final c = phone.replaceAll(RegExp(r'[^\d+]'), '');
    if (c.isEmpty) { _snack('No phone number available'); return; }
    try { await launchUrl(Uri(scheme: 'tel', path: c)); } catch (_) {
      _snack('Could not open dialer.');
    }
  }

  Future<void> _launchWhatsApp(String phone) async {
    final c = phone.replaceAll(RegExp(r'[^\d]'), '');
    if (c.isEmpty) { _snack('No phone number available'); return; }
    final uri = Uri.parse(
        'https://wa.me/$c?text=${Uri.encodeComponent(_predefinedMsg)}');
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else { _snack('WhatsApp not installed.'); }
    } catch (_) { _snack('Could not open WhatsApp.'); }
  }

  Future<void> _launchSMS(String phone) async {
    final c = phone.replaceAll(RegExp(r'[^\d+]'), '');
    if (c.isEmpty) { _snack('No phone number available'); return; }
    final uri = Uri(scheme: 'sms', path: c,
        queryParameters: {'body': _predefinedMsg});
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else { _snack('Could not open SMS app.'); }
    } catch (_) { _snack('Could not open SMS app.'); }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
  }

  void _showContactOptions(BloodBank bank) {
    final phone = bank.effectivePhone;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40, height: 4,
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2)),
              ),
            ),
            Text(bank.name,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 4),
            Text(phone,
                style: TextStyle(fontSize: 12, color: Colors.grey[500])),
            if (!bank.hasRealPhone) ...[
              const SizedBox(height: 2),
              Text('(demo number)',
                  style: TextStyle(
                      fontSize: 10,
                      color: Colors.amber[700],
                      fontStyle: FontStyle.italic)),
            ],
            const SizedBox(height: 14),
            // Pre-filled message preview
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey[200]!),
              ),
              child: Text(_predefinedMsg,
                  style: TextStyle(
                      fontSize: 11, color: Colors.grey[700], height: 1.4)),
            ),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: _contactBtn(
                  Icons.call_rounded, 'Call', Colors.green[600]!, () {
                Navigator.pop(ctx); _launchCall(phone);
              })),
              const SizedBox(width: 10),
              Expanded(child: _contactBtn(
                  Icons.chat_rounded, 'WhatsApp', const Color(0xFF25D366), () {
                Navigator.pop(ctx); _launchWhatsApp(phone);
              })),
              const SizedBox(width: 10),
              Expanded(child: _contactBtn(
                  Icons.sms_rounded, 'SMS', Colors.blue[600]!, () {
                Navigator.pop(ctx); _launchSMS(phone);
              })),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _contactBtn(IconData icon, String label, Color color,
      VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.3),
                blurRadius: 6, offset: const Offset(0, 3))
          ],
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(
              color: Colors.white, fontSize: 11,
              fontWeight: FontWeight.bold)),
        ]),
      ),
    );
  }

  // ── Filtered list ─────────────────────────────────────────
  List<BloodBank> get _filtered {
    return _bloodBanks.where((b) {
      // Search
      final q          = _searchQuery.toLowerCase();
      final matchSearch = q.isEmpty ||
          b.name.toLowerCase().contains(q) ||
          b.area.toLowerCase().contains(q) ||
          b.address.toLowerCase().contains(q) ||
          b.type.toLowerCase().contains(q);

      // Type filter
      final matchType = _selectedType == 'All' || b.type == _selectedType;

      // Source filter
      final matchSource = _sourceFilter == 'All' ||
          (_sourceFilter == 'eRaktKosh' &&
              (b.source == BankSource.eRaktKosh || b.source == BankSource.both)) ||
          (_sourceFilter == 'OSM Only' && b.source == BankSource.osm);

      // Blood group filter (only applies to eRaktKosh entries)
      bool matchBlood = true;
      if (_bloodGroupFilter != null && b.bloodStock != null) {
        matchBlood = (b.bloodStock![_bloodGroupFilter!] ?? 0) > 0;
      }

      return matchSearch && matchType && matchSource && matchBlood;
    }).toList();
  }

  Color _typeColor(String type) {
    switch (type) {
      case 'Government': return Colors.red[700]!;
      case 'Private':    return Colors.blue[700]!;
      case 'Trust':      return Colors.orange[700]!;
      default:           return Colors.grey[700]!;
    }
  }

  Color _sourceColor(BankSource s) {
    switch (s) {
      case BankSource.eRaktKosh: return Colors.green[700]!;
      case BankSource.osm:       return Colors.purple[700]!;
      case BankSource.both:      return Colors.teal[700]!;
    }
  }

  String _sourceLabel(BankSource s) {
    switch (s) {
      case BankSource.eRaktKosh: return 'eRaktKosh';
      case BankSource.osm:       return 'OSM';
      case BankSource.both:      return 'Verified';
    }
  }

  // ── BUILD ─────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Blood Banks — Mumbai'),
        backgroundColor: Colors.red[700],
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
            onPressed: _fetchAll,
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(icon: Icon(Icons.map),  text: 'Map'),
            Tab(icon: Icon(Icons.list), text: 'List'),
          ],
        ),
      ),
      body: Column(children: [
        // ── Search bar ───────────────────────────────────────
        Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          color: Colors.red[700],
          child: Column(children: [
            TextField(
              controller: _searchController,
              onChanged: (v) =>
                  setState(() { _searchQuery = v; _selectedBank = null; }),
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Search name, area, type...',
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
                prefixIcon: const Icon(Icons.search, color: Colors.white),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                  icon: const Icon(Icons.clear, color: Colors.white),
                  onPressed: () => setState(() {
                    _searchController.clear(); _searchQuery = '';
                  }),
                ) : null,
                filled: true,
                fillColor: Colors.white.withOpacity(0.18),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
            ),
            if (_lastFetched != null) ...[
              const SizedBox(height: 6),
              Row(children: [
                Icon(Icons.circle, size: 8, color: Colors.greenAccent[400]),
                const SizedBox(width: 6),
                Text(
                  'eRaktKosh + OSM · ${_erkCount + _osmCount} found · '
                      'Updated ${_formatAge(_lastFetched!)}',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.85), fontSize: 11),
                ),
              ]),
            ],
          ]),
        ),

        // ── Stats + filters ──────────────────────────────────
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          child: Column(children: [
            // Stats row
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _statCard('Total',    _bloodBanks.length.toString(),                                       Colors.red[700]!),
                  _statCard('eRaktKosh', _bloodBanks.where((b) => b.source != BankSource.osm).length.toString(), Colors.green[700]!),
                  _statCard('OSM',       _bloodBanks.where((b) => b.source == BankSource.osm).length.toString(),  Colors.purple[700]!),
                  _statCard('Verified',  _bloodBanks.where((b) => b.source == BankSource.both).length.toString(), Colors.teal[700]!),
                ]),
            const SizedBox(height: 10),

            // Type chips
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                ..._typeFilters.map((t) => _filterChip(
                  t, _selectedType == t, Colors.red[700]!,
                      () => setState(() => _selectedType = t),
                )),
                const SizedBox(width: 12),
                // Source chips
                ..._sourceFilters.map((s) => _filterChip(
                  s, _sourceFilter == s, Colors.green[700]!,
                      () => setState(() => _sourceFilter = s),
                )),
              ]),
            ),
            const SizedBox(height: 8),

            // Blood group filter chips (scroll)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _filterChip(
                  'All Blood', _bloodGroupFilter == null, Colors.grey[700]!,
                      () => setState(() => _bloodGroupFilter = null),
                ),
                ..._bloodGroups.map((bg) => _filterChip(
                  bg, _bloodGroupFilter == bg, Colors.red[800]!,
                      () => setState(() => _bloodGroupFilter = bg),
                )),
              ]),
            ),
          ]),
        ),

        // ── Tab content ──────────────────────────────────────
        Expanded(
          child: _isLoading
              ? _buildLoading()
              : _errorMessage != null
              ? _buildError()
              : _bloodBanks.isEmpty
              ? _buildEmpty()
              : TabBarView(
            controller: _tabController,
            children: [_buildMap(), _buildList()],
          ),
        ),
      ]),
    );
  }

  Widget _filterChip(
      String label, bool selected, Color color, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: FilterChip(
        label: Text(label,
            style: TextStyle(
                fontSize: 11,
                color: selected ? Colors.white : Colors.grey[700])),
        selected: selected,
        onSelected: (_) => onTap(),
        selectedColor: color,
        backgroundColor: Colors.grey[100],
        checkmarkColor: Colors.white,
        side: BorderSide(color: selected ? color : Colors.grey[300]!),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        padding: const EdgeInsets.symmetric(horizontal: 4),
      ),
    );
  }

  // ── Loading ───────────────────────────────────────────────
  Widget _buildLoading() => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CircularProgressIndicator(color: Colors.red[700]),
        const SizedBox(height: 16),
        const Text('Fetching from eRaktKosh + OpenStreetMap…',
            textAlign: TextAlign.center),
        const SizedBox(height: 6),
        Text('Combining government + crowd-sourced data',
            style: TextStyle(color: Colors.grey[500], fontSize: 12)),
      ],
    ),
  );

  // ── Error ─────────────────────────────────────────────────
  Widget _buildError() => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.wifi_off, size: 64, color: Colors.grey[400]),
        const SizedBox(height: 16),
        Text(_errorMessage ?? 'Error',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey[600])),
        const SizedBox(height: 20),
        ElevatedButton.icon(
          onPressed: _fetchAll,
          icon: const Icon(Icons.refresh),
          label: const Text('Try Again'),
          style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red[700],
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10))),
        ),
      ]),
    ),
  );

  // ── Empty ─────────────────────────────────────────────────
  Widget _buildEmpty() => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(Icons.search_off, size: 64, color: Colors.grey[400]),
      const SizedBox(height: 12),
      Text('No blood banks found.', style: TextStyle(color: Colors.grey[600])),
      const SizedBox(height: 20),
      ElevatedButton.icon(
        onPressed: _fetchAll,
        icon: const Icon(Icons.refresh),
        label: const Text('Refresh'),
        style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red[700], foregroundColor: Colors.white),
      ),
    ]),
  );

  // ── Map View ─────────────────────────────────────────────
  Widget _buildMap() {
    final filtered = _filtered;
    return Stack(children: [
      FlutterMap(
        mapController: _mapController,
        options: const MapOptions(
          initialCenter: _mumbaiCenter,
          initialZoom: 11.5,
          minZoom: 10,
          maxZoom: 18,
        ),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.hospital.app',
            tileProvider: CancellableNetworkTileProvider(),
          ),
          MarkerLayer(
            markers: filtered.map((bank) {
              final isSel  = _selectedBank?.id == bank.id;
              final color  = _typeColor(bank.type);
              // eRaktKosh banks with available blood get a green halo
              final hasBlood = bank.hasAvailableBlood;
              return Marker(
                width: isSel ? 52 : 38,
                height: isSel ? 52 : 38,
                point: LatLng(bank.latitude, bank.longitude),
                child: GestureDetector(
                  onTap: () {
                    setState(() => _selectedBank = bank);
                    _mapController.move(
                        LatLng(bank.latitude, bank.longitude), 15);
                  },
                  child: Stack(alignment: Alignment.center, children: [
                    if (isSel)
                      Icon(Icons.circle, size: 52,
                          color: color.withOpacity(0.25)),
                    if (hasBlood && !isSel)
                      Icon(Icons.circle, size: 38,
                          color: Colors.green.withOpacity(0.20)),
                    Icon(Icons.local_hospital,
                        size: isSel ? 40 : 30, color: color,
                        shadows: [Shadow(
                            color: Colors.black.withOpacity(0.4),
                            blurRadius: 4)]),
                  ]),
                ),
              );
            }).toList(),
          ),
        ],
      ),

      // Legend
      Positioned(
        top: 12, right: 12,
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: const [
                BoxShadow(color: Colors.black26, blurRadius: 6)
              ]),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Type', style: TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 10)),
                const SizedBox(height: 4),
                _legendItem(Colors.red[700]!,    'Government'),
                _legendItem(Colors.blue[700]!,   'Private'),
                _legendItem(Colors.orange[700]!, 'Trust'),
                const SizedBox(height: 6),
                const Text('Source', style: TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 10)),
                const SizedBox(height: 4),
                _legendItemDot(Colors.green[700]!,  'eRaktKosh'),
                _legendItemDot(Colors.purple[700]!, 'OSM'),
                _legendItemDot(Colors.teal[700]!,   'Both'),
              ]),
        ),
      ),

      // Count badge
      Positioned(
        top: 12, left: 12,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
              color: Colors.red[700],
              borderRadius: BorderRadius.circular(20)),
          child: Text('${filtered.length} found',
              style: const TextStyle(
                  color: Colors.white, fontSize: 12,
                  fontWeight: FontWeight.bold)),
        ),
      ),

      // Selected bank card
      if (_selectedBank != null)
        Positioned(
          bottom: 16, left: 16, right: 16,
          child: _buildDetailCard(_selectedBank!),
        ),
    ]);
  }

  // ── List View ────────────────────────────────────────────
  Widget _buildList() {
    final filtered = _filtered;
    if (filtered.isEmpty) {
      return Center(
        child: Text('No results.',
            style: TextStyle(color: Colors.grey[500])),
      );
    }
    return RefreshIndicator(
      onRefresh: _fetchAll,
      color: Colors.red[700],
      child: ListView.builder(
        padding: const EdgeInsets.all(14),
        itemCount: filtered.length,
        itemBuilder: (_, i) => _buildListCard(filtered[i]),
      ),
    );
  }

  Widget _buildListCard(BloodBank bank) {
    final color    = _typeColor(bank.type);
    final isSel    = _selectedBank?.id == bank.id;
    final srcColor = _sourceColor(bank.source);
    final srcLabel = _sourceLabel(bank.source);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: isSel ? 4 : 1.5,
      color: isSel ? Colors.red[50] : Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: isSel
            ? BorderSide(color: Colors.red[300]!, width: 1.5)
            : BorderSide.none,
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10)),
                  child: Icon(Icons.local_hospital, color: color, size: 26),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedBank = bank;
                        _tabController.animateTo(0);
                      });
                      _mapController.move(
                          LatLng(bank.latitude, bank.longitude), 15);
                    },
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(bank.name,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 14)),
                          const SizedBox(height: 3),
                          _infoRow(Icons.place, bank.area, Colors.grey[600]!),
                          _infoRow(Icons.access_time, bank.timing,
                              Colors.green[700]!),
                          if (bank.address != 'Mumbai')
                            _infoRow(Icons.location_on, bank.address,
                                Colors.grey[500]!),
                        ]),
                  ),
                ),
                Column(crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      // Type badge
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                            color: color,
                            borderRadius: BorderRadius.circular(5)),
                        child: Text(bank.type,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 9,
                                fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(height: 4),
                      // Source badge
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                            color: srcColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(5),
                            border: Border.all(
                                color: srcColor.withOpacity(0.5))),
                        child: Text(srcLabel,
                            style: TextStyle(
                                color: srcColor, fontSize: 9,
                                fontWeight: FontWeight.bold)),
                      ),
                    ]),
              ]),

              // ── Blood stock chips (eRaktKosh only) ──────────
              if (bank.hasStockData) ...[
                const SizedBox(height: 10),
                const Text('Blood Stock',
                    style: TextStyle(fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: Colors.black54)),
                const SizedBox(height: 5),
                Wrap(spacing: 5, runSpacing: 5,
                    children: bank.bloodStock!.entries.map((e) {
                      final avail = e.value > 0;
                      return Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: avail
                              ? Colors.green[50]
                              : Colors.red[50],
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: avail
                                ? Colors.green[300]!
                                : Colors.red[200]!,
                          ),
                        ),
                        child: Text(
                          '${e.key}  ${avail ? e.value : "✗"}',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: avail
                                ? Colors.green[800]
                                : Colors.red[400],
                          ),
                        ),
                      );
                    }).toList()),
              ],

              const SizedBox(height: 10),
              // Contact button
              SizedBox(
                width: double.infinity,
                height: 40,
                child: ElevatedButton.icon(
                  onPressed: () => _showContactOptions(bank),
                  icon: const Icon(Icons.contact_phone, size: 16),
                  label: Text(
                    bank.hasRealPhone
                        ? 'Contact  ${bank.phone}'
                        : 'Contact Blood Bank',
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.bold),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red[700],
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ),
            ]),
      ),
    );
  }

  // ── Detail Card ─────────────────────────────────────────
  Widget _buildDetailCard(BloodBank bank) {
    final color = _typeColor(bank.type);
    return Card(
      elevation: 10,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(5)),
                  child: Text(bank.type,
                      style: const TextStyle(
                          color: Colors.white, fontSize: 9,
                          fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(
                      color: _sourceColor(bank.source).withOpacity(0.12),
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(
                          color: _sourceColor(bank.source).withOpacity(0.5))),
                  child: Text(_sourceLabel(bank.source),
                      style: TextStyle(
                          color: _sourceColor(bank.source), fontSize: 9,
                          fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 8),
                Expanded(child: Text(bank.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 14))),
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: () => setState(() => _selectedBank = null),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ]),
              const Divider(height: 14),
              _infoRow(Icons.location_on, bank.address, Colors.grey[600]!),
              const SizedBox(height: 4),
              _infoRow(Icons.access_time, bank.timing, Colors.green[700]!),
              const SizedBox(height: 4),
              _infoRow(Icons.place, bank.area, Colors.grey[600]!),

              // Blood stock
              if (bank.hasStockData) ...[
                const SizedBox(height: 10),
                const Text('Live Blood Stock',
                    style: TextStyle(fontSize: 11,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 5),
                Wrap(spacing: 5, runSpacing: 5,
                    children: bank.bloodStock!.entries.map((e) {
                      final ok = e.value > 0;
                      return Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: ok ? Colors.green[50] : Colors.red[50],
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                              color: ok
                                  ? Colors.green[300]!
                                  : Colors.red[200]!),
                        ),
                        child: Text(
                          '${e.key}  ${ok ? e.value : "✗"}',
                          style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              color: ok
                                  ? Colors.green[800]
                                  : Colors.red[400]),
                        ),
                      );
                    }).toList()),
              ],

              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: SizedBox(height: 42,
                    child: ElevatedButton.icon(
                      onPressed: () => _launchCall(bank.effectivePhone),
                      icon: const Icon(Icons.call, size: 15),
                      label: const Text('Call',
                          style: TextStyle(fontSize: 12)),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green[600],
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          padding: EdgeInsets.zero),
                    ))),
                const SizedBox(width: 6),
                Expanded(child: SizedBox(height: 42,
                    child: ElevatedButton.icon(
                      onPressed: () =>
                          _launchWhatsApp(bank.effectivePhone),
                      icon: const Icon(Icons.chat_rounded, size: 15),
                      label: const Text('WhatsApp',
                          style: TextStyle(fontSize: 12)),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF25D366),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          padding: EdgeInsets.zero),
                    ))),
                const SizedBox(width: 6),
                Expanded(child: SizedBox(height: 42,
                    child: ElevatedButton.icon(
                      onPressed: () => _launchSMS(bank.effectivePhone),
                      icon: const Icon(Icons.sms_rounded, size: 15),
                      label: const Text('SMS',
                          style: TextStyle(fontSize: 12)),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue[600],
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          padding: EdgeInsets.zero),
                    ))),
              ]),
            ]),
      ),
    );
  }

  // ── Helpers ──────────────────────────────────────────────
  Widget _statCard(String label, String value, Color color) => Column(
    children: [
      Text(value, style: TextStyle(
          fontSize: 20, fontWeight: FontWeight.bold, color: color)),
      Text(label, style: TextStyle(fontSize: 10, color: Colors.grey[600])),
    ],
  );

  Widget _legendItem(Color color, String label) => Padding(
    padding: const EdgeInsets.only(bottom: 3),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.local_hospital, color: color, size: 12),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(fontSize: 10)),
    ]),
  );

  Widget _legendItemDot(Color color, String label) => Padding(
    padding: const EdgeInsets.only(bottom: 3),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 10, height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(fontSize: 10)),
    ]),
  );

  Widget _infoRow(IconData icon, String text, Color color) => Padding(
    padding: const EdgeInsets.only(bottom: 2),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, size: 12, color: color),
      const SizedBox(width: 4),
      Expanded(child: Text(text,
          style: TextStyle(fontSize: 11, color: color),
          maxLines: 2, overflow: TextOverflow.ellipsis)),
    ]),
  );

  String _formatAge(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inSeconds < 60) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    return '${diff.inHours}h ago';
  }
}